// Global variables

let word = ""; // The word to guess
let userGuessParam = ""; // To count number of characters in a word
const maxAttempts = 6; // Maximum number of attempts allowed
const wordLength = 5; // Length of the word to guess
let attempts = 0; // Current number of attempts
let gameOver = false; // Flag to indicate if the game is over
let wordChars = {}; // Empty object to count duplicate characters
let modal; // For the win and lose screen



// Initialize when the page loads
// It has to load async due to the API call.
window.onload = async function() {
    
    // This has to be async and await; otherwise there is a timing issue.
    const wordFromApi = await getWordFromApi();

    // Assign the results to word
    word = wordFromApi;

    // Set the initial variables and game settings
    const closeModal = document.getElementById("modalCloseID");
    modal = document.getElementById("modalWindow");

    // Run these functions onload
    drawBoard();
    usedLetterBoard();
    disabledButtonIfEmpty();

    // Prepare the UI
    document.getElementById("restartButton").style.display = "block"; //show
    document.getElementById("wordGuess").style.display = "none"; // hide
    document.getElementById("submitButton").style.display = "none"; // hide
    document.getElementById("gameInstructions").style.display = "none"; // hide
    document.getElementById("modalWindow").style.display = "none"; // hide    

    // When the user clicks on <span> (x), close the modal
    if (closeModal) {
        closeModal.onclick = function() {
            modal.style.display = "none";
        }
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target.id === "modalWindow") {
        modal.style.display = "none";
      }
    }

}

async function startGame() {
    // Reset the attempts counter (this is what controls the game)
    attempts = 0;
    gameOver = false;

    // Fetch a new word from the API
    const wordFromApi = await getWordFromApi();
    word = wordFromApi;

    // Show the word to guess in the console for the professors
    console.log("New word from restart: ", word);


    // Toggle button visibility
    document.getElementById("wordGuess").style.display = "block";
    document.getElementById("submitButton").style.display = "block";
    document.getElementById("gameInstructions").style.display = "block";
    document.getElementById("restartButton").style.display = "none";
    document.getElementById("modalWindow").style.display = "none"; // hide


    // Clear all boxes
    const gameGrid = document.querySelectorAll('.boxBorder');
    for (let i = 0; i < 30; i++) {
        gameGrid[i].textContent = "";
        gameGrid[i].className = "boxBorder";
    }
    
    // Reset alphabet board
    const alphabetBoxes = document.querySelectorAll('#usedLetterBoard span');
    for (let i = 0; i < alphabetBoxes.length; i++) {
        alphabetBoxes[i].className = "boxBorder";
    }
    
    // Clear input
    document.getElementById("wordGuess").value = "";
    
    // Re-disable button
    disabledButtonIfEmpty();
}

// Create the elements for the game board
function drawBoard() {

    // Grab container
    const gameContainer = document.querySelector('.gameContainer');

    // Render Rows
    for (row = 0; row < wordLength; row++) {

        // Render columns
        for (column = 0; column < maxAttempts; column ++) {

            // Create the element
            const newTextBox = document.createElement('span');
            
            // Modify the properties
            newTextBox.textContent = ""
            newTextBox.className = "boxBorder"
            
            // Draw on the DOM
            gameContainer.appendChild(newTextBox)
        }
    }

}

// Don't let the user submit if the input is less than five characters
function disabledButtonIfEmpty() {
    const button = document.getElementById("submitButton")
    const inputField = document.getElementById("wordGuess")

    if (inputField.value.length < 5) {
        button.disabled = true;
        button.className = "submitWordButton disabled"
    } else {
        button.disabled = false;
        button.className = "submitWordButton"
    }
}

// User enters their guess word
function guessWord() {

    // Check if the user run out of attempts
    checkGameOver()

    const userGuessInput = document.getElementById("wordGuess")
    const userGuess = document.getElementById('wordGuess').value.toUpperCase();
    
    // Check if the input is exactly 5 letters
    if (userGuess.length !== wordLength) {
        alert("Please enter exactly 5 letters");
        return; // Stop here, don't process
    }
    
    // Grab the element
    const insertUserGuessInBox = document.querySelectorAll('.boxBorder')

    // Calculate which row to fill
    const startRow = attempts * 5;

    // Insert one letter per box
    for (let i = 0; i < userGuess.length; i++) {
        insertUserGuessInBox[startRow + i].textContent = userGuess[i];
    }

    // Count duplicates and color the boxes
    addColorIndicatorsToGameGrid(word, userGuess);

    // Color the used alphabet board
    addColorIndicatorsToUsedLetterBoard(userGuess, word)

    // Clear input
    userGuessInput.value = ""

    // Advance to next row
    attempts++;

    // Game Win
    gameWon(userGuess, word)

    if (userGuess === word) {
        return; // Don't call checkGameOver if won
    }
    checkGameOver()
}

// User wins by guessing the word
function gameWon(userGuess, word) {
    if (userGuess === word) {
        setTimeout(function() {
            
            // Toggle button visibility
            document.getElementById("submitButton").style.display = "none";
            document.getElementById("restartButton").style.display = "block";
            document.getElementById("wordGuess").style.display = "none";
            document.getElementById("gameInstructions").style.display = "none"; // hide
            document.getElementById("modalWindow").style.display = "flex"; // show
            document.getElementById("modalContentText").innerHTML = "🏆<br><br>You won!<br> You guessed the word: <br>" + word;


        }, 100)
    }
    disabledButtonIfEmpty();


}

// User loses
function checkGameOver() {
    if (attempts === 6) {
         setTimeout(function() {

        // Toggle button visibility
        document.getElementById("wordGuess").style.display = "none";
        document.getElementById("submitButton").style.display = "none";
        document.getElementById("restartButton").style.display = "block";
        document.getElementById("modalWindow").style.display = "flex";
        document.getElementById("modalContentText").innerHTML = "🤪<br>Game Over!<br><br> The word was: <br> " + word;


        }, 100)
    }
}

// Show color indicators to Used Letter Board
function addColorIndicatorsToUsedLetterBoard(userGuess, word) {
    const alphabetBoxes = document.querySelectorAll('#usedLetterBoard span');
    
    // Go through each letter in the alphabet board
    for (let i = 0; i < alphabetBoxes.length; i ++) {
        let box = alphabetBoxes[i];
        let letter = box.textContent;

        
        // Check if this letter is in the user's guess
        for (let i = 0; i < userGuess.length; i++) {
            if (letter === userGuess[i]) {
                // Check if it's the correct position
                if (letter === word[i]) {
                    box.className = "boxBorder green";
                }
                // Check if it's in the word but wrong position
                else if (word.includes(letter)) {
                    box.className = "boxBorder yellow";
                } 
                // Mark the letter as used
                else {
                     box.className = "boxBorder gray";
                }
                
            }
        }
    }
}

// Function to check how many letters are duplicated and assign color codes
function addColorIndicatorsToGameGrid(word, userGuessParam) {

    // reset wordChars
    wordChars = {};

    // Reassign to userGuess
    userGuess = userGuessParam;
    
    for (i = 0; i < word.length; i++) {
        let char = word[i];
        wordChars[char] = (wordChars[char] || 0) + 1; 
    }
    console.log("WordChars: ", wordChars);
    console.log("User Guess: ", userGuess);

    const insertUserGuessInBox = document.querySelectorAll('.boxBorder');
    const startRow = attempts * 5;

    for (i = 0; i < userGuess.length; i++) {

        // Color it green if it's in the correct position
        if (wordChars[userGuess[i]] && word[i] === userGuess[i]) {
            insertUserGuessInBox[startRow + i].className = "boxBorder green";

            // Substract to decrease the number of duplicated characters
            wordChars[userGuess[i]]--; 
            console.log("all: " + userGuess[i]);
        }

        // Make it yellow
        else if (wordChars[userGuess[i]] && word[i] != userGuess[i]) {
            insertUserGuessInBox[startRow + i].className = "boxBorder yellow";

            // Substract to decrease the number of duplicated characters
            wordChars[userGuess[i]]--;
            console.log("all: " + userGuess[i]);
        }
        else {
            insertUserGuessInBox[startRow + i].className = "boxBorder gray";
        }
    }
}

// Allow only alphabet letters
function alphabet() {
    let upperCaseAlphabet = ""
    for (let i = 65; i <= 90; i++) {
        upperCaseAlphabet += String.fromCharCode(i)
    }

    return upperCaseAlphabet;

}

function usedLetterBoard(userGuess) {
    userGuess = document.getElementById('wordGuess').value.toUpperCase();
    
    let usedLetterContainer = document.getElementById("usedLetterBoard");
    
    // Assign the alphabet function
    const alphabetString = alphabet();
    
    // Create the letter board
    for (let i = 0; i < alphabetString.length; i++) {

        // Create new element
        const usedLetterBox = document.createElement('span');
        
        // Modify the properties
        usedLetterBox.textContent = alphabetString[i];
        usedLetterBox.className = "boxBorder";
        
        // Draw on the DOM
        usedLetterContainer.appendChild(usedLetterBox);
        // addColorIndicatorsToGameGrid(userGuess, word)
    }

}

// Get a five letter word from this API. It needs no key.
// https://www.datamuse.com/api/

function getWordFromApi() {

    // Add return before fetch because it's a promise; otherwise it will be undefined
    // reference: https://www.youtube.com/watch?v=cuEtnrL9-H0
    return fetch('https://api.datamuse.com/words?sp=?????&max=100')
    .then(res => res.json())
    .then(data => {

        // The API retrieves 100 words. We only need one but random.
        const randomIndex = Math.floor(Math.random() * data.length);
        const randomWord = data[randomIndex].word;
        
        // Check the result
        // console.log("Randomized result from API: ", randomWord);
        
        if (data.length > 0) {
            wordResult = randomWord.toUpperCase();
            // console.log("Word from API result: ", wordResult);
            return wordResult
        }
        return null;
    })
    
}